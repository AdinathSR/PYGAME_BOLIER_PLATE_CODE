from setuptools import setup

setup(name="pygameUtilsforlazypeople",
version="0.4.2",
description="this is beshte",
author="Adinath",
packages=["pygameUtilslazy"],
install_requires=['pygame']
)