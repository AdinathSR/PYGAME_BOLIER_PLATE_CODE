import pygame

class main:
    def __init__(self, run= True, width=500, height=500, WINcolor=(255,255,255), FPS=60, *args):
        self.run = run
        self.WIN = pygame.display.set_mode((width, height))
        self.color = WINcolor
        self.fps = FPS
        self.clock = pygame.time.Clock()
        for i in args:
            i()
        
    def exit(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.run = False
            
            
    
    def main_loop(self, *args):
        while self.run:
            self.exit()
            self.draw_screen()
            
            self.update_screen()
    
    def draw_screen(self):
        self.WIN.fill(self.color)
    
    def update_screen(self):
        pygame.display.update()

    def draw_rect(self, width, height, color, x, y, surface):
        pygame.draw.rect(surface=surface, color=color, rect=[x, y, width, height])

    # def get_oreesed_keys(,):
       
    # TODO:
    # def conduct_task_based_on_inp(self,self, WANTED_input_keys_andthirefunc):
    #     self.key_state = pygame.key.get_pressed()
    #     self.keysstate=[]
    #     self.wntedinp=WANTED_input_keys_andthirefunc[:0]
    #     for i in self.wntedinp:
    #         self.keysstate.append(self.key_state[i])

    # def inputmange(self, inputkeys, task):
    #     self.inpkeys = inputkeys
         
        
        